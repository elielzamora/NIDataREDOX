﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace DataREDOXProgram
{
    public partial class dataredox : Form
    {

        public List<List<String>> matrix = new List<List<String>>();
        public List<String> dataHeader = new List<String>();
        public String[] items = null;
        public List<bool> checkedItems = new List<bool>(); 
        public dataredox()
        {
            InitializeComponent();
            // Set filter options and filter index.
            //OpenFile.Filter = "Text Files (.txt)|*.txt|CSV (.csv)|*.csv|All Files (*.*)|*.*";
            //OpenFile.FilterIndex = 2;
            //OpenFile.Multiselect = false;
        }

        private void openFileDialog2_FileOk(object sender, CancelEventArgs e)
        {
            var openFile = sender as OpenFileDialog;
            openFileTextBox.Text = openFile.FileName;
            //find headers
            findHeaders();
            if (this.items != null && items.Length > 2)
            {
                for(int i = 0; i < items.Length; i++)
                {
                    Checklist.Items.Add(items[i], false);
                }
                Checklist.SetItemCheckState(0, CheckState.Checked);
                Checklist.SetItemCheckState(1, CheckState.Checked);
            }
            else
            {

            }
            
        }

        private void saveFileDialog1_FileOk(object sender, CancelEventArgs e)
        {
            var saveFile = sender as SaveFileDialog;
            saveFileTextBox.Text = saveFile.FileName;
        }

        private void textBox1_Click(object sender, EventArgs e)
        {
            OpenFile.ShowDialog();
        }

        private void textBox2_Click(object sender, EventArgs e)
        {
            SaveFile.ShowDialog();
        }
        private string[] findHeaders()
        {
            string[] headers = null;
            System.IO.StreamReader reader = null;
            try
            {
                reader = new System.IO.StreamReader(openFileTextBox.Text);
                //while(reader.ReadLine().Equals(""))
                dataHeader.Add(reader.ReadLine());//MessageBox.Show(reader.ReadLine());
                dataHeader.Add(reader.ReadLine());//MessageBox.Show(reader.ReadLine());
                dataHeader.Add(reader.ReadLine());//MessageBox.Show(reader.ReadLine());
                dataHeader.Add(reader.ReadLine());//MessageBox.Show(reader.ReadLine());
                dataHeader.Add(reader.ReadLine());//MessageBox.Show(reader.ReadLine());
                dataHeader.Add(reader.ReadLine());//MessageBox.Show(reader.ReadLine());
                this.items = dataHeader[5].Split(',');//MessageBox.Show(reader.ReadLine());
                return this.items;
            }
            catch
            {
                MessageBox.Show("Sorry an error has occured.");
            }
            finally
            {
                if (reader != null)
                { 
                    reader.Close();
                }
            }
            return null;
        }
        public void checkItems()
        {
            for(int i = 0; i < Checklist.Items.Count; i++)
            {
                if (Checklist.GetItemCheckState(i).Equals(CheckState.Checked))
                {
                    checkedItems.Insert(i, true);
                }else if(Checklist.GetItemCheckState(i).Equals(CheckState.Unchecked))
                {
                    checkedItems.Insert(i, false);
                }
            }
        }
        private void reduceButtonClick(object sender, EventArgs e)
        {
            reduceButton.Text = "Processing";
            Application.DoEvents();
            if (openFileTextBox.Text.Length > 0 && saveFileTextBox.Text.Length > 0)
            {
                if ( items != null && ReductionFactor.Value > 0 )
                {
                    //checkedItems();
                    StreamReader reader = null;
                    StreamWriter writer = null;
                    try
                    {
                        reader = new StreamReader(openFileTextBox.Text);
                        writer = new StreamWriter(saveFileTextBox.Text);
                        //read NI VI Logger
                        writer.WriteLine(reader.ReadLine());
                        //created date
                        writer.WriteLine(reader.ReadLine());
                        // Change number of scans
                        var scanLine = reader.ReadLine();
                        string[] separators = { ": " };
                        int numberOfScans = Int32.Parse(scanLine.Split(separators, StringSplitOptions.RemoveEmptyEntries)[1]);
                        numberOfScans = (int)numberOfScans / Decimal.ToInt32(ReductionFactor.Value);
                        writer.WriteLine(scanLine.Split(separators, StringSplitOptions.RemoveEmptyEntries)[0]
                            + ": " + numberOfScans.ToString());
                        // Change scan rate
                        scanLine = reader.ReadLine();
                        decimal scanRate = Decimal.Parse(
                            scanLine.Split(separators, StringSplitOptions.RemoveEmptyEntries)[1]
                            .Split(' ')[0]
                        );
                        scanRate = scanRate * ReductionFactor.Value;
                        writer.WriteLine(scanLine.Split(separators, StringSplitOptions.RemoveEmptyEntries)[0]
                            + ": " + scanRate.ToString() + " " +
                            scanLine.Split(separators, StringSplitOptions.RemoveEmptyEntries)[1]
                            .Split(' ')[1]);
                        //write blank line
                        writer.WriteLine();
                        // check items
                        checkItems();
                        //write header
                        bool first = true;
                        for (int i = 0; i < items.Length; i++)
                        {
                            if (checkedItems[i]) {
                                if (first == true)
                                {
                                    writer.Write(items[i]);
                                    first = false;
                                }else
                                {
                                    writer.Write("," + items[i]);
                                }
                            }
                        }
                        writer.Write("\n");
                        //read blank row
                        reader.ReadLine();
                        //read table title
                        reader.ReadLine();
                        //write rows
                        string line;
                        int count = 0;
                        while ((line = reader.ReadLine()) != null)
                        {
                            first = true;
                            string [] col = line.Split(',');
                            if (count % Decimal.ToInt32(ReductionFactor.Value) == 0)
                            {
                                //MessageBox.Show(line);
                                for (int i = 0; i < col.Length; i++)
                                {
                                    if (checkedItems[i])
                                    {
                                        if (first == true)
                                        {
                                            writer.Write(col[i]);
                                            first = false;
                                        }
                                        else
                                        {
                                            writer.Write("," + col[i]);
                                        }
                                    }
                                }
                                writer.Write("\n");
                            }
                            count++;
                        }
                        //completed
                        MessageBox.Show("Completed!");
                    }//end try
                    catch (Exception ex)
                    {
                        //MessageBox.Show(ex.StackTrace);
                        strangeError();
                    }
                    finally
                    {
                        if (reader != null)
                        {
                            reader.Close();
                        }
                        if (writer != null)
                        {
                            writer.Close();
                        }
                    }
                }else
                {
                    strangeError();
                }
            }
            else
            {
                MessageBox.Show("Please select a file to load and specify where to save it");
            }
            reduceButton.Text = "Reduce";
        }
        //private void checkedItems();
        private void strangeError()
        {
            MessageBox.Show("A Strange Error encountered and the program was not able to reduce your data.\n"
                + "Make sure the files you selected are not open and being used and that you have access to the files that you have selected.");
        }

        private void label2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The laws of data reduction..." + "\n" +
                "1. do not talk about data reduction" + "\n" +
                "2. do not talk about data reduction" + "\n" +
                "3. there is no such thing as reducing data _too_ much");
        }
    }
}