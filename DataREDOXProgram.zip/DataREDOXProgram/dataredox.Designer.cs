﻿namespace DataREDOXProgram
{
    partial class dataredox
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.OpenFile = new System.Windows.Forms.OpenFileDialog();
            this.label2 = new System.Windows.Forms.Label();
            this.SaveFile = new System.Windows.Forms.SaveFileDialog();
            this.label3 = new System.Windows.Forms.Label();
            this.openFileTextBox = new System.Windows.Forms.TextBox();
            this.saveFileTextBox = new System.Windows.Forms.TextBox();
            this.Checklist = new System.Windows.Forms.CheckedListBox();
            this.reduceButton = new System.Windows.Forms.Button();
            this.ReductionFactor = new System.Windows.Forms.NumericUpDown();
            this.ReductionFactorLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.ReductionFactor)).BeginInit();
            this.SuspendLayout();
            // 
            // OpenFile
            // 
            this.OpenFile.Filter = "CSV|*.csv|Text|*.txt|All Files|*.*";
            this.OpenFile.FileOk += new System.ComponentModel.CancelEventHandler(this.openFileDialog2_FileOk);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(118, 13);
            this.label2.TabIndex = 0;
            this.label2.Text = "Select a File to Reduce";
            this.label2.DoubleClick += new System.EventHandler(this.label2_Click);
            // 
            // SaveFile
            // 
            this.SaveFile.Filter = "CSV|*.csv|Text|*.txt|All Files|*.*";
            this.SaveFile.FileOk += new System.ComponentModel.CancelEventHandler(this.saveFileDialog1_FileOk);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 48);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(199, 13);
            this.label3.TabIndex = 1;
            this.label3.Text = "Select Where to Save the Reduced File.";
            // 
            // openFileTextBox
            // 
            this.openFileTextBox.Location = new System.Drawing.Point(15, 25);
            this.openFileTextBox.Name = "openFileTextBox";
            this.openFileTextBox.Size = new System.Drawing.Size(462, 20);
            this.openFileTextBox.TabIndex = 2;
            this.openFileTextBox.Click += new System.EventHandler(this.textBox1_Click);
            // 
            // saveFileTextBox
            // 
            this.saveFileTextBox.Location = new System.Drawing.Point(15, 64);
            this.saveFileTextBox.Name = "saveFileTextBox";
            this.saveFileTextBox.Size = new System.Drawing.Size(462, 20);
            this.saveFileTextBox.TabIndex = 3;
            this.saveFileTextBox.Click += new System.EventHandler(this.textBox2_Click);
            // 
            // Checklist
            // 
            this.Checklist.FormattingEnabled = true;
            this.Checklist.Location = new System.Drawing.Point(15, 94);
            this.Checklist.Name = "Checklist";
            this.Checklist.Size = new System.Drawing.Size(462, 454);
            this.Checklist.TabIndex = 4;
            // 
            // reduceButton
            // 
            this.reduceButton.Location = new System.Drawing.Point(402, 554);
            this.reduceButton.Name = "reduceButton";
            this.reduceButton.Size = new System.Drawing.Size(75, 23);
            this.reduceButton.TabIndex = 5;
            this.reduceButton.Text = "Reduce";
            this.reduceButton.UseVisualStyleBackColor = true;
            this.reduceButton.Click += new System.EventHandler(this.reduceButtonClick);
            // 
            // ReductionFactor
            // 
            this.ReductionFactor.Location = new System.Drawing.Point(140, 556);
            this.ReductionFactor.Maximum = new decimal(new int[] {
            99999999,
            0,
            0,
            0});
            this.ReductionFactor.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.ReductionFactor.Name = "ReductionFactor";
            this.ReductionFactor.Size = new System.Drawing.Size(256, 20);
            this.ReductionFactor.TabIndex = 6;
            this.ReductionFactor.Value = new decimal(new int[] {
            1,
            0,
            0,
            0});
            // 
            // ReductionFactorLabel
            // 
            this.ReductionFactorLabel.AutoSize = true;
            this.ReductionFactorLabel.Location = new System.Drawing.Point(12, 559);
            this.ReductionFactorLabel.Name = "ReductionFactorLabel";
            this.ReductionFactorLabel.Size = new System.Drawing.Size(89, 13);
            this.ReductionFactorLabel.TabIndex = 7;
            this.ReductionFactorLabel.Text = "Reduction Factor";
            // 
            // dataredox
            // 
            this.ClientSize = new System.Drawing.Size(489, 584);
            this.Controls.Add(this.ReductionFactorLabel);
            this.Controls.Add(this.ReductionFactor);
            this.Controls.Add(this.reduceButton);
            this.Controls.Add(this.Checklist);
            this.Controls.Add(this.saveFileTextBox);
            this.Controls.Add(this.openFileTextBox);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Name = "dataredox";
            ((System.ComponentModel.ISupportInitialize)(this.ReductionFactor)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.CheckedListBox checkedListBox1;
        private System.Windows.Forms.OpenFileDialog OpenFile;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.SaveFileDialog SaveFile;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox openFileTextBox;
        private System.Windows.Forms.TextBox saveFileTextBox;
        private System.Windows.Forms.CheckedListBox Checklist;
        private System.Windows.Forms.Button reduceButton;
        private System.Windows.Forms.NumericUpDown ReductionFactor;
        private System.Windows.Forms.Label ReductionFactorLabel;
    }
}

